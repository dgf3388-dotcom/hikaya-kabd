import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  ArrowLeft,
  Check,
  Clock,
  Copy,
  Flame,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  ShoppingBag,
  Star,
  UtensilsCrossed,
  X,
} from "lucide-react";
import {
  ADDRESS,
  CATEGORIES,
  DISHES,
  FEATURES,
  GALLERY,
  HOURS,
  HOURS_LABEL,
  MAPS_URL,
  NAV,
  PHONE_DISPLAY,
  PHONE_TEL,
  PLANS,
  PLUS_CODE,
  REVIEWS,
  formatPrice,
  isOpenNow,
  riyadhParts,
  whatsappUrl,
  type DishCategory,
  type PlanId,
} from "@/data/restaurant";

const OFFER_KEY = "hikayat-offer";

type Offer = { name: string; email: string; plan: PlanId; at: string };

function readOffer(): Offer | null {
  try {
    const raw = localStorage.getItem(OFFER_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Offer;
    if (!parsed.email) return null;
    return parsed;
  } catch {
    return null;
  }
}

function planMessage(planId: PlanId) {
  const plan = PLANS.find((p) => p.id === planId);
  return `السلام عليكم، أبي أطلب باقة «${plan?.name ?? "حكاية الخبر"}» من مطعم حكايات كبدة وسجق.`;
}

export function HomePage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("story");
  const [plan, setPlan] = useState<PlanId>("tale");
  const [category, setCategory] = useState<DishCategory | "all">("all");
  const [cart, setCart] = useState<Record<string, number>>({});
  const [openNow, setOpenNow] = useState<boolean | null>(null);
  const [today, setToday] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [offer, setOffer] = useState<Offer | null>(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [formError, setFormError] = useState("");
  const [editing, setEditing] = useState(false);
  const [zoom, setZoom] = useState<{ src: string; alt: string } | null>(null);

  useEffect(() => {
    const tick = () => {
      setOpenNow(isOpenNow());
      setToday(riyadhParts().dayId);
    };
    tick();
    const id = window.setInterval(tick, 30_000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    const saved = readOffer();
    if (saved) {
      setOffer(saved);
      setName(saved.name);
      setEmail(saved.email);
      setPlan(saved.plan);
    }
  }, []);

  useEffect(() => {
    const nodes = NAV.map((item) => document.getElementById(item.id)).filter(
      (node): node is HTMLElement => Boolean(node),
    );
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(visible.target.id);
      },
      { rootMargin: "-45% 0px -45% 0px", threshold: [0.15, 0.4] },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!menuOpen && !zoom) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setMenuOpen(false);
        setZoom(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [menuOpen, zoom]);

  const visibleDishes = useMemo(
    () =>
      category === "all" ? DISHES : DISHES.filter((dish) => dish.category === category),
    [category],
  );

  const cartLines = DISHES.filter((dish) => cart[dish.id]).map((dish) => ({
    dish,
    qty: cart[dish.id] ?? 0,
  }));
  const cartCount = cartLines.reduce((sum, line) => sum + line.qty, 0);
  const cartTotal = cartLines.reduce((sum, line) => sum + line.qty * line.dish.price, 0);

  function addDish(id: string) {
    setCart((current) => ({ ...current, [id]: (current[id] ?? 0) + 1 }));
  }

  function removeDish(id: string) {
    setCart((current) => {
      const next = { ...current };
      const qty = (next[id] ?? 0) - 1;
      if (qty <= 0) delete next[id];
      else next[id] = qty;
      return next;
    });
  }

  function choosePlan(next: PlanId) {
    setPlan(next);
    document.getElementById("signup")?.scrollIntoView({ behavior: "smooth" });
  }

  async function copyAddress() {
    try {
      await navigator.clipboard.writeText(`${ADDRESS} · ${PLUS_CODE}`);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  }

  function submitOffer(event: FormEvent) {
    event.preventDefault();
    const trimmedEmail = email.trim();
    const trimmedName = name.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setFormError("اكتب بريداً صحيحاً عشان نرسل لك العروض.");
      return;
    }
    const next: Offer = {
      name: trimmedName,
      email: trimmedEmail,
      plan,
      at: new Date().toISOString(),
    };
    localStorage.setItem(OFFER_KEY, JSON.stringify(next));
    setOffer(next);
    setFormError("");
    setEditing(false);
  }

  function sendCart() {
    const lines = cartLines
      .map((line) => `• ${line.dish.name} × ${line.qty}`)
      .join("\n");
    const planName = PLANS.find((item) => item.id === plan)?.name;
    const message = `السلام عليكم، طلب من حكايات كبدة وسجق:\n${lines}\nالمجموع التقريبي: ${cartTotal} ر.س\nالباقة المهتم فيها: ${planName}`;
    window.open(whatsappUrl(message), "_blank", "noopener,noreferrer");
  }

  return (
    <div className="min-h-screen bg-parchment text-ink">
      <header className="fixed inset-x-0 top-0 z-40 border-b border-ink-soft bg-ink text-cream">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
          <a href="#top" className="flex min-w-0 items-center gap-2">
            <span className="grid size-9 shrink-0 place-items-center rounded-full bg-chili text-cream">
              <Flame className="size-4" aria-hidden />
            </span>
            <span className="min-w-0">
              <span className="block truncate font-display text-lg leading-none">حكايات</span>
              <span className="block truncate text-xs text-parchment-deep">كبدة وسجق · الخبر</span>
            </span>
          </a>

          <nav className="hidden items-center gap-1 lg:flex" aria-label="أقسام الصفحة">
            {NAV.map((item) => (
              <a
                key={item.id}
                href={item.href}
                className={`rounded-full px-3 py-2 text-sm transition-colors duration-200 ${
                  active === item.id
                    ? "bg-cream text-ink"
                    : "text-parchment hover:bg-ink-soft"
                }`}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <a
              href={whatsappUrl(planMessage(plan))}
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-11 items-center gap-2 rounded-full bg-chili px-4 text-sm font-semibold text-cream transition-colors duration-200 hover:bg-chili-deep"
            >
              <MessageCircle className="size-4" aria-hidden />
              <span className="hidden sm:inline">اطلب الآن</span>
              <span className="sm:hidden">اطلب</span>
            </a>
            <button
              type="button"
              className="grid size-11 place-items-center rounded-full border border-ink-soft text-cream lg:hidden"
              aria-expanded={menuOpen}
              aria-controls="mobile-nav"
              onClick={() => setMenuOpen((value) => !value)}
            >
              {menuOpen ? <X className="size-5" /> : <Menu className="size-5" />}
              <span className="sr-only">{menuOpen ? "إغلاق القائمة" : "فتح القائمة"}</span>
            </button>
          </div>
        </div>

        {menuOpen ? (
          <nav
            id="mobile-nav"
            className="border-t border-ink-soft bg-ink px-4 py-3 lg:hidden"
            aria-label="أقسام الصفحة"
          >
            <ul className="grid gap-1">
              {NAV.map((item) => (
                <li key={item.id}>
                  <a
                    href={item.href}
                    onClick={() => setMenuOpen(false)}
                    className="flex min-h-11 items-center rounded-xl px-3 text-cream hover:bg-ink-soft"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
              <li>
                <a
                  href="#signup"
                  onClick={() => setMenuOpen(false)}
                  className="flex min-h-11 items-center rounded-xl px-3 text-ember hover:bg-ink-soft"
                >
                  سجّل بريدك للعروض
                </a>
              </li>
            </ul>
          </nav>
        ) : null}
      </header>

      <main id="top">
        <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 pt-24 pb-12 sm:px-6 lg:grid-cols-2 lg:pt-28 lg:pb-20">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full border border-line bg-cream px-3 py-1 text-sm text-ink-soft">
              <span className="size-2 rounded-full bg-chili" aria-hidden />
              مطعم مأكولات مصرية · الخبر الشمالية
            </p>
            <h1 className="mt-4 text-4xl text-ink sm:text-5xl lg:text-6xl">
              كبدة إسكندراني وسجق بلدي، بطعم يرجّعك لأيام زمان
            </h1>
            <p className="mt-4 max-w-xl text-lg text-muted">
              في شارع الملك سلمان، ساندوتش الفينو لسا على أصوله. جودة الأكل واضحة،
              والسعر واضح، والاستقبال ما يتغيّر من أول ما تدخل.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a
                href={whatsappUrl(planMessage("tale"))}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-11 items-center gap-2 rounded-full bg-chili px-5 text-sm font-semibold text-cream transition-colors duration-200 hover:bg-chili-deep"
              >
                <MessageCircle className="size-4" aria-hidden />
                اطلب للاستلام
              </a>
              <a
                href="#plans"
                className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-cream px-5 text-sm font-semibold text-ink transition-colors duration-200 hover:border-chili"
              >
                شوف الباقات
                <ArrowLeft className="size-4" aria-hidden />
              </a>
            </div>
            <dl className="mt-8 grid grid-cols-3 gap-3 border-t border-line pt-6">
              <div>
                <dt className="text-xs text-muted">التقييم</dt>
                <dd className="mt-1 flex items-center gap-1 font-display text-2xl">
                  ٤٫٧
                  <Star className="size-4 fill-ember text-ember" aria-hidden />
                </dd>
              </div>
              <div>
                <dt className="text-xs text-muted">للشخص</dt>
                <dd className="mt-1 font-display text-2xl">٢٠–٤٠</dd>
              </div>
              <div>
                <dt className="text-xs text-muted">الحالة</dt>
                <dd className="mt-1 text-sm font-semibold">
                  {openNow === null ? "كل يوم" : openNow ? "مفتوح الآن" : "مغلق حالياً"}
                  <span className="mt-1 block font-normal text-muted">{HOURS_LABEL}</span>
                </dd>
              </div>
            </dl>
          </div>

          <figure className="relative">
            <img
              src="/photos/board.jpg"
              alt="ساندوتشات كبدة وسجق على لوح خشب مع ليمون وفلفل"
              className="aspect-square w-full rounded-3xl object-cover"
            />
            <figcaption className="absolute inset-x-4 bottom-4 flex items-center justify-between gap-3 rounded-2xl bg-ink/90 px-4 py-3 text-cream">
              <span>
                <span className="block text-sm font-semibold">١٩٧ تعليق</span>
                <span className="block text-xs text-parchment-deep">الناس رجعت وخلّته المفضل</span>
              </span>
              <span className="flex gap-0.5" aria-label="تقييم خمس نجوم">
                {Array.from({ length: 5 }).map((_, index) => (
                  <Star key={index} className="size-4 fill-ember text-ember" aria-hidden />
                ))}
              </span>
            </figcaption>
          </figure>
        </section>

        <section
          id="story"
          className="scroll-mt-24 border-y border-line bg-cream"
        >
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
            <img
              src="/photos/hawawshi.jpg"
              alt="حواشي بالجرجير مع طحينة ومخلل وسلطة"
              className="aspect-square w-full rounded-3xl object-cover"
            />
            <div>
              <p className="text-sm font-semibold text-chili">الحكاية باختصار</p>
              <h2 className="mt-2 text-4xl sm:text-5xl">أكل مصري أصلي، من غير لف ودوران</h2>
              <p className="mt-4 text-lg text-muted">
                حكايات كبدة وسجق مطعم في الخبر الشمالية. الكبدة إسكندراني، السجق بلدي،
                والفينو سخن. الزوار يمدحون ثلاثة أشياء تتكرر: جودة الأكل، السعر،
                والموظفين المحترمين.
              </p>
              <ul className="mt-6 grid gap-3">
                {[
                  "جلوس داخل المكان وطعام سفري",
                  "مفتوح يومياً من الصباح لين الثانية فجراً",
                  "شارع الملك سلمان، تقاطع الشارع السابع",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-ember-soft text-chili">
                      <Check className="size-3.5" aria-hidden />
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <a
                href="#features"
                className="mt-8 inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-chili"
              >
                شوف ليش يرجعون
                <ArrowLeft className="size-4" aria-hidden />
              </a>
            </div>
          </div>
        </section>

        <section id="gallery" className="scroll-mt-24">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-20">
            <div className="max-w-xl">
              <p className="text-sm font-semibold text-chili">من الصحن</p>
              <h2 className="mt-2 text-4xl sm:text-5xl">صور الأكل، مو تصوير استوديو</h2>
            </div>
            <div className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
              {GALLERY.map((photo) => (
                <button
                  key={photo.src}
                  type="button"
                  onClick={() => setZoom(photo)}
                  className="overflow-hidden rounded-3xl"
                >
                  <img
                    src={photo.src}
                    alt={photo.alt}
                    className="aspect-square w-full object-cover transition-transform duration-200 hover:scale-105"
                  />
                </button>
              ))}
            </div>
          </div>
        </section>

        <section id="features" className="scroll-mt-24">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div className="max-w-xl">
                <p className="text-sm font-semibold text-chili">المزايا</p>
                <h2 className="mt-2 text-4xl sm:text-5xl">اللي يخلي الزيارة تستاهل</h2>
              </div>
              <a
                href={MAPS_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-cream px-5 text-sm font-semibold transition-colors duration-200 hover:border-chili"
              >
                <MapPin className="size-4" aria-hidden />
                الاتجاهات
              </a>
            </div>
            <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((feature) =>
                "image" in feature ? (
                  <article
                    key={feature.title}
                    className="relative min-h-72 overflow-hidden rounded-3xl sm:col-span-1"
                  >
                    <img
                      src={feature.image}
                      alt={feature.alt}
                      className="absolute inset-0 h-full w-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/30 to-transparent" />
                    <div className="absolute inset-x-0 bottom-0 p-5 text-cream">
                      <h3 className="text-3xl">{feature.title}</h3>
                      <p className="mt-2 text-sm text-parchment">{feature.text}</p>
                    </div>
                  </article>
                ) : (
                  <article
                    key={feature.title}
                    className="flex flex-col justify-between rounded-3xl border border-line bg-cream p-6"
                  >
                    <span className="grid size-11 place-items-center rounded-2xl bg-ember-soft text-chili">
                      {feature.title.includes("سعر") ? (
                        <UtensilsCrossed className="size-5" aria-hidden />
                      ) : feature.title.includes("جلوس") ? (
                        <ShoppingBag className="size-5" aria-hidden />
                      ) : (
                        <Clock className="size-5" aria-hidden />
                      )}
                    </span>
                    <div className="mt-8">
                      <h3 className="text-3xl">{feature.title}</h3>
                      <p className="mt-2 text-muted">{feature.text}</p>
                    </div>
                  </article>
                ),
              )}
            </div>
          </div>
        </section>

        <section id="plans" className="scroll-mt-24 bg-ink text-cream">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <div className="max-w-2xl">
              <p className="text-sm font-semibold text-ember">الباقات</p>
              <h2 className="mt-2 text-4xl text-cream sm:text-5xl">كم تدفع، ووش تاخذ</h2>
              <p className="mt-4 text-parchment">
                حسب ٦٩ زائر، أغلب الفواتير بين ٢٠ و٤٠ ر.س للشخص. اختر الباقة اللي
                تناسبك، ونجهّزها للاستلام أو للجلوس.
              </p>
            </div>
            <div className="mt-10 grid gap-4 lg:grid-cols-3">
              {PLANS.map((item) => {
                const selected = plan === item.id;
                return (
                  <article
                    key={item.id}
                    className={`flex flex-col rounded-3xl border p-6 transition-colors duration-200 ${
                      item.popular
                        ? "border-ember bg-ink-soft"
                        : "border-ink-soft bg-ink"
                    } ${selected ? "ring-2 ring-ember" : ""}`}
                  >
                    <div className="flex items-center justify-between gap-3">
                      <h3 className="text-3xl text-cream">{item.name}</h3>
                      {item.popular ? (
                        <span className="rounded-full bg-chili px-3 py-1 text-xs font-semibold text-cream">
                          الأكثر طلباً
                        </span>
                      ) : null}
                    </div>
                    <p className="mt-4 font-display text-5xl text-ember">
                      {item.range}
                      <span className="ms-2 font-sans text-base text-parchment">ر.س</span>
                    </p>
                    <p className="mt-3 text-parchment">{item.blurb}</p>
                    <ul className="mt-6 grid flex-1 gap-2 text-sm">
                      {item.items.map((line) => (
                        <li key={line} className="flex items-center gap-2">
                          <Check className="size-4 text-ember" aria-hidden />
                          {line}
                        </li>
                      ))}
                    </ul>
                    <button
                      type="button"
                      onClick={() => choosePlan(item.id)}
                      className={`mt-6 inline-flex min-h-11 items-center justify-center rounded-full px-5 text-sm font-semibold transition-colors duration-200 ${
                        item.popular
                          ? "bg-chili text-cream hover:bg-chili-deep"
                          : "bg-cream text-ink hover:bg-parchment"
                      }`}
                    >
                      {selected ? "الباقة مختارة" : "اختَر هالباقة"}
                    </button>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        <section id="menu" className="scroll-mt-24">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div className="max-w-xl">
                <p className="text-sm font-semibold text-chili">القائمة</p>
                <h2 className="mt-2 text-4xl sm:text-5xl">ركّب طلبك وأرسله</h2>
                <p className="mt-3 text-muted">
                  أسعار المنيو نفسه. أضف اللي تبيه ونجهّز رسالة واتساب جاهزة.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() =>
                setZoom({ src: "/photos/menu.jpg", alt: "منيو حكايات كبدة وسجق" })
              }
              className="mt-8 block w-full overflow-hidden rounded-3xl border border-line bg-ink"
            >
              <img
                src="/photos/menu.jpg"
                alt="منيو حكايات كبدة وسجق: ساندوتشات الكبدة والسجق والحواشي والوجبات"
                className="mx-auto max-h-[42rem] w-full object-contain"
              />
            </button>
            <p className="mt-2 text-sm text-muted">اضغط الصورة لتكبير المنيو.</p>

            <div className="mt-8 flex flex-wrap gap-2" role="tablist" aria-label="تصفية القائمة">
              {CATEGORIES.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={category === item.id}
                  onClick={() => setCategory(item.id)}
                  className={`min-h-11 rounded-full px-4 text-sm font-semibold transition-colors duration-200 ${
                    category === item.id
                      ? "bg-ink text-cream"
                      : "border border-line bg-cream text-ink hover:border-chili"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {visibleDishes.map((dish) => {
                const qty = cart[dish.id] ?? 0;
                return (
                  <li
                    key={dish.id}
                    className="flex items-center justify-between gap-3 rounded-2xl border border-line bg-cream p-4"
                  >
                    <div>
                      <p className="font-semibold">{dish.name}</p>
                      <p className="text-sm text-muted">{dish.note}</p>
                      <p className="mt-1 text-sm font-semibold text-chili tabular-nums">
                        {formatPrice(dish.price)} ر.س
                      </p>
                    </div>
                    {qty === 0 ? (
                      <button
                        type="button"
                        onClick={() => addDish(dish.id)}
                        className="inline-flex min-h-11 shrink-0 items-center rounded-full bg-ink px-4 text-sm font-semibold text-cream transition-colors duration-200 hover:bg-ink-soft"
                      >
                        أضف
                      </button>
                    ) : (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => removeDish(dish.id)}
                          className="grid size-11 place-items-center rounded-full border border-line bg-parchment text-lg"
                          aria-label={`إنقاص ${dish.name}`}
                        >
                          −
                        </button>
                        <span className="w-6 text-center font-semibold tabular-nums">{qty}</span>
                        <button
                          type="button"
                          onClick={() => addDish(dish.id)}
                          className="grid size-11 place-items-center rounded-full bg-chili text-lg text-cream"
                          aria-label={`زيادة ${dish.name}`}
                        >
                          +
                        </button>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>

            {cartCount > 0 ? (
              <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-3xl bg-ink px-5 py-4 text-cream">
                <div>
                  <p className="font-semibold">
                    {formatPrice(cartCount)} في السلة · {formatPrice(cartTotal)} ر.س
                  </p>
                  <p className="text-sm text-parchment-deep">المجموع حسب أسعار المنيو</p>
                </div>
                <button
                  type="button"
                  onClick={sendCart}
                  className="inline-flex min-h-11 items-center gap-2 rounded-full bg-chili px-5 text-sm font-semibold text-cream transition-colors duration-200 hover:bg-chili-deep"
                >
                  <MessageCircle className="size-4" aria-hidden />
                  أرسل الطلب
                </button>
              </div>
            ) : (
              <p className="mt-6 text-sm text-muted">أضف صنفاً وبنجهّز رسالة الطلب جاهزة على واتساب.</p>
            )}
          </div>
        </section>

        <section id="reviews" className="scroll-mt-24 border-y border-line bg-cream">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
            <div className="grid gap-8 lg:grid-cols-[16rem_1fr] lg:items-end">
              <div>
                <p className="text-sm font-semibold text-chili">آراء الزوار</p>
                <p className="mt-2 font-display text-6xl">٤٫٧</p>
                <div className="mt-2 flex gap-0.5" aria-hidden>
                  {Array.from({ length: 5 }).map((_, index) => (
                    <Star key={index} className="size-4 fill-ember text-ember" />
                  ))}
                </div>
                <p className="mt-2 text-muted">من ١٩٧ تعليق على جوجل</p>
              </div>
              <h2 className="text-4xl sm:text-5xl">الناس ما تجامل في الكبدة</h2>
            </div>
            <div className="mt-10 grid gap-4 lg:grid-cols-3">
              {REVIEWS.map((review) => (
                <figure key={review.name} className="flex flex-col rounded-3xl border border-line bg-parchment p-6">
                  <div className="flex gap-0.5" aria-label="خمس نجوم">
                    {Array.from({ length: 5 }).map((_, index) => (
                      <Star key={index} className="size-4 fill-ember text-ember" aria-hidden />
                    ))}
                  </div>
                  <blockquote className="mt-4 flex-1 text-lg">{review.quote}</blockquote>
                  <figcaption className="mt-6 border-t border-line pt-4">
                    <p className="font-semibold">{review.name}</p>
                    <p className="text-sm text-muted">{review.meta}</p>
                    <p className="mt-3 text-sm text-ink-soft">رد المالك: {review.reply}</p>
                  </figcaption>
                </figure>
              ))}
            </div>
            <div className="mt-8">
              <a
                href="#visit"
                className="inline-flex min-h-11 items-center gap-2 rounded-full bg-chili px-5 text-sm font-semibold text-cream transition-colors duration-200 hover:bg-chili-deep"
              >
                زُرنا اليوم
                <ArrowLeft className="size-4" aria-hidden />
              </a>
            </div>
          </div>
        </section>

        <section id="visit" className="scroll-mt-24">
          <div className="mx-auto grid max-w-6xl gap-6 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-24">
            <div className="rounded-3xl border border-line bg-cream p-6 sm:p-8">
              <p className="text-sm font-semibold text-chili">الزيارة</p>
              <h2 className="mt-2 text-4xl">وين نحن، ومتى نفتح</h2>
              <p className="mt-4 text-muted">{ADDRESS}</p>
              <p className="mt-1 text-sm text-muted">الرمز: {PLUS_CODE}</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <a
                  href={MAPS_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex min-h-11 items-center gap-2 rounded-full bg-ink px-5 text-sm font-semibold text-cream transition-colors duration-200 hover:bg-ink-soft"
                >
                  <MapPin className="size-4" aria-hidden />
                  الاتجاهات
                </a>
                <a
                  href={`tel:${PHONE_TEL}`}
                  className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line px-5 text-sm font-semibold transition-colors duration-200 hover:border-chili"
                >
                  <Phone className="size-4" aria-hidden />
                  {PHONE_DISPLAY}
                </a>
                <button
                  type="button"
                  onClick={copyAddress}
                  className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line px-5 text-sm font-semibold transition-colors duration-200 hover:border-chili"
                >
                  {copied ? <Check className="size-4" aria-hidden /> : <Copy className="size-4" aria-hidden />}
                  {copied ? "تم نسخ العنوان" : "انسخ العنوان"}
                </button>
              </div>
            </div>
            <div className="rounded-3xl border border-line bg-cream p-6 sm:p-8">
              <div className="flex items-center justify-between gap-3">
                <h3 className="text-3xl">الدوام</h3>
                <span
                  className={`rounded-full px-3 py-1 text-xs font-semibold ${
                    openNow
                      ? "bg-ember-soft text-ink"
                      : "bg-parchment-deep text-ink-soft"
                  }`}
                >
                  {openNow === null ? "…" : openNow ? "مفتوح الآن" : "مغلق حالياً"}
                </span>
              </div>
              <ul className="mt-4 divide-y divide-line">
                {HOURS.map((day) => (
                  <li
                    key={day.id}
                    className={`flex items-center justify-between py-2 text-sm ${
                      today === day.id ? "font-semibold text-chili" : ""
                    }`}
                  >
                    <span>{day.label}{today === day.id ? " · اليوم" : ""}</span>
                    <span className="tabular-nums">{HOURS_LABEL}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section id="signup" className="scroll-mt-24 bg-chili text-cream">
          <div className="mx-auto grid max-w-6xl gap-8 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:items-center lg:py-20">
            <div>
              <p className="text-sm font-semibold text-ember-soft">خلّك قريب</p>
              <h2 className="mt-2 text-4xl text-cream sm:text-5xl">سجّل بريدك، وبنرسل طبق الأسبوع</h2>
              <p className="mt-4 text-parchment">
                عروض بسيطة، من غير إزعاج. اختر الباقة اللي تهمك، ونرجعلك لما يجهز شيء يستاهل.
              </p>
            </div>

            {offer && !editing ? (
              <div className="rounded-3xl bg-cream p-6 text-ink">
                <p className="font-display text-3xl">تم، بريدك عندنا</p>
                <p className="mt-2 text-muted">
                  {offer.name ? `${offer.name} · ` : ""}
                  {offer.email}
                </p>
                <p className="mt-1 text-sm text-muted">
                  الباقة: {PLANS.find((item) => item.id === offer.plan)?.name}
                </p>
                <div className="mt-5 flex flex-wrap gap-3">
                  <a
                    href={whatsappUrl(planMessage(offer.plan))}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex min-h-11 items-center gap-2 rounded-full bg-chili px-5 text-sm font-semibold text-cream"
                  >
                    اطلب هالباقة الآن
                  </a>
                  <button
                    type="button"
                    onClick={() => setEditing(true)}
                    className="inline-flex min-h-11 items-center rounded-full border border-line px-5 text-sm font-semibold"
                  >
                    تعديل البريد
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={submitOffer} className="rounded-3xl bg-cream p-6 text-ink" noValidate>
                <label className="block text-sm font-semibold" htmlFor="guest-name">
                  الاسم
                </label>
                <input
                  id="guest-name"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  autoComplete="name"
                  className="mt-2 min-h-11 w-full rounded-xl border border-line bg-parchment px-3 outline-none"
                  placeholder="اسمك"
                />
                <label className="mt-4 block text-sm font-semibold" htmlFor="guest-email">
                  البريد الإلكتروني
                </label>
                <input
                  id="guest-email"
                  type="email"
                  required
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  autoComplete="email"
                  className="mt-2 min-h-11 w-full rounded-xl border border-line bg-parchment px-3 outline-none"
                  placeholder="you@email.com"
                />
                <label className="mt-4 block text-sm font-semibold" htmlFor="guest-plan">
                  الباقة اللي تهمك
                </label>
                <select
                  id="guest-plan"
                  value={plan}
                  onChange={(event) => setPlan(event.target.value as PlanId)}
                  className="mt-2 min-h-11 w-full rounded-xl border border-line bg-parchment px-3"
                >
                  {PLANS.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} · {item.range} ر.س
                    </option>
                  ))}
                </select>
                {formError ? <p className="mt-3 text-sm font-semibold text-chili">{formError}</p> : null}
                <button
                  type="submit"
                  className="mt-5 inline-flex min-h-11 w-full items-center justify-center rounded-full bg-ink text-sm font-semibold text-cream transition-colors duration-200 hover:bg-ink-soft"
                >
                  سجّلني في العروض
                </button>
              </form>
            )}
          </div>
        </section>
      </main>

      <footer className="bg-ink text-parchment">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-3">
          <div>
            <p className="font-display text-3xl text-cream">حكايات كبدة وسجق</p>
            <p className="mt-2 text-sm">مطعم مأكولات مصرية في الخبر. جلوس وطعام سفري.</p>
          </div>
          <div className="text-sm">
            <p>{ADDRESS}</p>
            <p className="mt-2">{PLUS_CODE}</p>
            <a className="mt-2 inline-flex min-h-11 items-center text-ember" href={`tel:${PHONE_TEL}`}>
              {PHONE_DISPLAY}
            </a>
          </div>
          <div className="flex flex-col items-start gap-2 text-sm">
            {NAV.map((item) => (
              <a key={item.id} href={item.href} className="inline-flex min-h-11 items-center hover:text-cream">
                {item.label}
              </a>
            ))}
            <a href="#signup" className="inline-flex min-h-11 items-center font-semibold text-ember">
              سجّل بريدك
            </a>
          </div>
        </div>
      </footer>
      {zoom ? (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-ink/90 p-4"
          role="dialog"
          aria-modal="true"
          aria-label={zoom.alt}
          onClick={() => setZoom(null)}
        >
          <button
            type="button"
            className="absolute end-4 top-4 grid size-11 place-items-center rounded-full bg-cream text-ink"
            onClick={() => setZoom(null)}
          >
            <X className="size-5" />
            <span className="sr-only">إغلاق الصورة</span>
          </button>
          <img
            src={zoom.src}
            alt={zoom.alt}
            className="max-h-full max-w-full rounded-2xl object-contain"
          />
        </div>
      ) : null}
    </div>
  );
}
