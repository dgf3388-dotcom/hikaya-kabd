export const PHONE_DISPLAY = "059 730 1800";
export const PHONE_TEL = "+966597301800";
export const WHATSAPP = "966597301800";

export const ADDRESS =
  "شارع الملك سلمان، تقاطع الشارع السابع، الخبر الشمالية، الخبر 31582";
export const PLUS_CODE = "76Q5+4C الخبر";

export const MAPS_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  "مطعم حكايات كبده وسجق الخبر شارع الملك سلمان",
)}`;

export function whatsappUrl(message: string) {
  return `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(message)}`;
}

export const HOURS = [
  { id: "sat", label: "السبت" },
  { id: "sun", label: "الأحد" },
  { id: "mon", label: "الاثنين" },
  { id: "tue", label: "الثلاثاء" },
  { id: "wed", label: "الأربعاء" },
  { id: "thu", label: "الخميس" },
  { id: "fri", label: "الجمعة" },
] as const;

export const HOURS_LABEL = "٧:٣٠ ص – ٢:٠٠ ص";

/** Open 07:30–02:00 Asia/Riyadh, every day. */
export function riyadhParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Riyadh",
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "";
  const weekday = get("weekday");
  const map: Record<string, (typeof HOURS)[number]["id"]> = {
    Sat: "sat",
    Sun: "sun",
    Mon: "mon",
    Tue: "tue",
    Wed: "wed",
    Thu: "thu",
    Fri: "fri",
  };
  return {
    dayId: map[weekday] ?? "sat",
    hour: Number(get("hour")),
    minute: Number(get("minute")),
  };
}

export function isOpenNow(date = new Date()) {
  const { hour, minute } = riyadhParts(date);
  const mins = hour * 60 + minute;
  const open = 7 * 60 + 30;
  const close = 2 * 60;
  return mins >= open || mins < close;
}

export const NAV = [
  { href: "#story", id: "story", label: "الحكاية" },
  { href: "#gallery", id: "gallery", label: "الصور" },
  { href: "#plans", id: "plans", label: "الباقات" },
  { href: "#menu", id: "menu", label: "المنيو" },
  { href: "#reviews", id: "reviews", label: "الآراء" },
  { href: "#visit", id: "visit", label: "الزيارة" },
] as const;

export type PlanId = "bite" | "tale" | "feast";

export const PLANS: {
  id: PlanId;
  name: string;
  range: string;
  blurb: string;
  items: string[];
  popular: boolean;
}[] = [
  {
    id: "bite",
    name: "لقمة سريعة",
    range: "١–٢٠",
    blurb: "سندوتش واحد للطريق. تطلع وأنت شبعان من غير ما تتأخر.",
    items: ["ساندوتش كبدة إسكندراني", "مخلل أو طحينة وثوم", "من ٨ ر.س"],
    popular: false,
  },
  {
    id: "tale",
    name: "حكاية الخبر",
    range: "٢٠–٤٠",
    blurb: "اللي يختاره أغلب الزوار. وجبة شخص كاملة، والطعم يرجّعك لأيام زمان.",
    items: ["وجبة كبدة إسكندراني", "أو سندوتشين من المنيو", "إضافة سلطة"],
    popular: true,
  },
  {
    id: "feast",
    name: "سفرة العيلة",
    range: "٤٠–٦٠",
    blurb: "طبقين على الطاولة، عيش سخن، وتقعدون لين تخلص الحكاية.",
    items: ["وجبة كبدة ووجبة سجق", "كريب رول", "مقبلات للطاولة"],
    popular: false,
  },
];

export type DishCategory =
  | "liver"
  | "sausage"
  | "hawawshi"
  | "hikayat"
  | "offal"
  | "pasta"
  | "crepe"
  | "meals"
  | "sides";

export const CATEGORIES: { id: DishCategory | "all"; label: string }[] = [
  { id: "all", label: "الكل" },
  { id: "liver", label: "كبدة" },
  { id: "sausage", label: "سجق" },
  { id: "hawawshi", label: "حواشي" },
  { id: "meals", label: "وجبات" },
  { id: "hikayat", label: "حكايات" },
  { id: "offal", label: "حلويات اللحوم" },
  { id: "pasta", label: "باستا" },
  { id: "crepe", label: "كريب" },
  { id: "sides", label: "إضافات" },
];

export const DISHES: {
  id: string;
  category: DishCategory;
  name: string;
  note: string;
  price: number;
}[] = [
  { id: "liv-alex", category: "liver", name: "ساندوتش كبدة إسكندراني", note: "١٥٠ سعرة", price: 8 },
  { id: "liv-grill", category: "liver", name: "ساندوتش كبدة جريل", note: "١٥٠ سعرة", price: 10 },
  { id: "liv-radda", category: "liver", name: "ساندوتش كبدة ردة", note: "٢٠٠ سعرة", price: 10 },
  { id: "liv-roast", category: "liver", name: "ساندوتش كبدة مشوية", note: "١٥٠ سعرة", price: 10 },
  { id: "liv-lamb", category: "liver", name: "ساندوتش كبدة غنم", note: "١٨٠ سعرة", price: 10 },
  { id: "so-alex", category: "sausage", name: "ساندوتش سجق إسكندراني", note: "٢٠٠ سعرة", price: 12 },
  { id: "so-grill", category: "sausage", name: "ساندوتش سجق جريل", note: "٢٣٠ سعرة", price: 12 },
  { id: "so-roast", category: "sausage", name: "ساندوتش سجق مشوي", note: "٢١٠ سعرة", price: 15 },
  { id: "haw-baladi", category: "hawawshi", name: "حواشي بلدي", note: "٢٠٠ سعرة", price: 12 },
  { id: "haw-pizza", category: "hawawshi", name: "حواشي وش بيتزا", note: "٢٥٠ سعرة", price: 15 },
  { id: "haw-mix", category: "hawawshi", name: "حواشي مكس", note: "٣٠٠ سعرة", price: 18 },
  { id: "hik-pane", category: "hikayat", name: "ساندوتش دجاج بانيه", note: "٢٠٠ سعرة", price: 10 },
  { id: "hik-strips", category: "hikayat", name: "ساندوتش دجاج ستربس", note: "٢٠٠ سعرة", price: 10 },
  { id: "hik-zinger", category: "hikayat", name: "ساندوتش دجاج زنجر", note: "٢٠٠ سعرة", price: 10 },
  { id: "hik-shrimp-p", category: "hikayat", name: "ساندوتش جمبري بانيه", note: "٢٢٠ سعرة", price: 12 },
  { id: "hik-shrimp-g", category: "hikayat", name: "ساندوتش جمبري جريل", note: "٢٥٠ سعرة", price: 12 },
  { id: "hik-fries", category: "hikayat", name: "ساندوتش بطاطس فارم", note: "١٨٠ سعرة", price: 6 },
  { id: "hik-meat", category: "hikayat", name: "ساندوتش لحمة بالبصل", note: "٢٥٠ سعرة", price: 15 },
  { id: "hik-kofta", category: "hikayat", name: "ساندوتش كفتة بالبصل", note: "٢٥٠ سعرة", price: 12 },
  { id: "hik-shish", category: "hikayat", name: "ساندوتش شيش", note: "٢٣٠ سعرة", price: 10 },
  { id: "off-mix", category: "offal", name: "ساندوتش مُشكّل", note: "٣٠٠ سعرة", price: 10 },
  { id: "off-head", category: "offal", name: "ساندوتش لحمة راس", note: "٢٥٠ سعرة", price: 10 },
  { id: "off-spleen", category: "offal", name: "ساندوتش طحال", note: "٢٠٠ سعرة", price: 10 },
  { id: "off-tongue", category: "offal", name: "ساندوتش لسان", note: "٢١٠ سعرة", price: 10 },
  { id: "off-fasha", category: "offal", name: "ساندوتش فشة", note: "٢٥٠ سعرة", price: 10 },
  { id: "pas-liv", category: "pasta", name: "باستا كبدة", note: "٣٢٠ سعرة", price: 20 },
  { id: "pas-so", category: "pasta", name: "باستا سجق", note: "٣٥٠ سعرة", price: 25 },
  { id: "pas-mix", category: "pasta", name: "باستا ميكس كبدة وسجق", note: "٤٠٠ سعرة", price: 25 },
  { id: "pas-kofta", category: "pasta", name: "باستا كفتة", note: "٣٠٠ سعرة", price: 25 },
  { id: "pas-beef", category: "pasta", name: "باستا لحمة مفرومة", note: "٣٢٠ سعرة", price: 25 },
  { id: "pas-strips", category: "pasta", name: "باستا ستربس", note: "٣٥٠ سعرة", price: 25 },
  { id: "pas-shrimp", category: "pasta", name: "باستا جمبري", note: "٣٨٠ سعرة", price: 30 },
  { id: "pas-red", category: "pasta", name: "باستا صوص أحمر", note: "٢٥٠ سعرة", price: 10 },
  { id: "cr-pane", category: "crepe", name: "كريب رول دجاج بانيه", note: "٢٢٠ سعرة", price: 20 },
  { id: "cr-strips", category: "crepe", name: "كريب رول ستربس", note: "٢٢٠ سعرة", price: 20 },
  { id: "cr-zinger", category: "crepe", name: "كريب رول زنجر", note: "٢٣٠ سعرة", price: 20 },
  { id: "cr-sausage", category: "crepe", name: "كريب رول سوسيس", note: "٢٥٠ سعرة", price: 20 },
  { id: "cr-liver", category: "crepe", name: "كريب رول كبدة", note: "٢٥٠ سعرة", price: 20 },
  { id: "meal-alex", category: "meals", name: "وجبة كبدة إسكندراني", note: "٣٥٠ سعرة", price: 20 },
  { id: "meal-radda", category: "meals", name: "وجبة كبدة ردة", note: "٣٨٠ سعرة", price: 25 },
  { id: "meal-lamb", category: "meals", name: "وجبة كبدة غنم", note: "٣٨٠ سعرة", price: 30 },
  { id: "meal-roast", category: "meals", name: "وجبة كبدة مشوية", note: "٣٢٠ سعرة", price: 25 },
  { id: "meal-so", category: "meals", name: "وجبة سجق إسكندراني", note: "٣٨٠ سعرة", price: 28 },
  { id: "side-salad", category: "sides", name: "سلطة خضراء شرائح", note: "١٠٠ سعرة", price: 6 },
  { id: "side-tahini", category: "sides", name: "طحينة وثوم", note: "١٥٠ سعرة", price: 5 },
  { id: "side-pickle", category: "sides", name: "مخلل", note: "٥٠ سعرة", price: 4 },
  { id: "side-mayo", category: "sides", name: "مايونيز سلطة", note: "٢٠٠ سعرة", price: 3 },
  { id: "side-cheese", category: "sides", name: "جبنة", note: "١٠٠ سعرة", price: 3 },
];

const priceFormat = new Intl.NumberFormat("ar-SA");

export function formatPrice(value: number) {
  return priceFormat.format(value);
}

export const GALLERY = [
  {
    src: "/photos/board.jpg",
    alt: "ساندوتشات كبدة وسجق على لوح خشب مع ليمون وفلفل ومخلل وطحينة",
  },
  {
    src: "/photos/platter.jpg",
    alt: "طبق كبدة وطبق سجق مع طحينة ومخلل وسلطة وصلصة",
  },
  {
    src: "/photos/hawawshi.jpg",
    alt: "حواشي بالجرجير مع طحينة ومخلل وسلطة ومشروب",
  },
  {
    src: "/photos/close.jpg",
    alt: "ساندوتش سجق بالبصل والفلفل داخل خبز فينو",
  },
] as const;

export const FEATURES = [
  {
    title: "كبدة إسكندراني",
    text: "تتبيلة توم وشطة وبقدونس. مو كبدة عابرة — الطعم اللي الزوار وصفوه بأصلي أصلي.",
    image: "/photos/platter.jpg",
    alt: "طبق كبدة إسكندراني مع ليمون وفلفل أخضر",
  },
  {
    title: "سجق على الفحم",
    text: "سجق بلدي يطلع سخن، والريحة توصل قبل الساندوتش.",
    image: "/photos/close.jpg",
    alt: "ساندوتش سجق قريب مع بصل وفلفل",
  },
  {
    title: "حواشي من الفرن",
    text: "عيش محمص، جرجير، وطحينة على الجنب. وجبة تقعد لها.",
    image: "/photos/hawawshi.jpg",
    alt: "حواشي محمص مع جرجير وطحينة ومخلل",
  },
  {
    title: "سعر واضح",
    text: "الساندوتش يبدأ من ٨ ر.س، والوجبة من ٢٠. الأرقام نفسها اللي على المنيو.",
  },
  {
    title: "جلوس وسفري",
    text: "تقعد جوا، أو تطلب وتاخذ أكلك. الاستقبال نفسه في الحالتين.",
  },
  {
    title: "لحد الثانية فجراً",
    text: "مفتوح كل يوم من ٧:٣٠ الصباح. بعد الدوام، وبعد العشا، لسا في كبدة.",
  },
] as const;

export const REVIEWS = [
  {
    name: "كريم صابر",
    meta: "٧ مراجعات · قبل ٣ أشهر",
    quote:
      "صراحة ممتاز جداً. جودة الأكل والسعر، والموظفين محترمين جداً. خلاص بقى المطعم المفضل ليا.",
    reply: "نورتنا وشرفتنا يا فندم",
  },
  {
    name: "هيثم إبراهيم",
    meta: "مرشد محلي · قبل ٤ أشهر",
    quote:
      "الناس ذوق، والكاشير شريف استقباله حلو. ساندوتشات الفينو الكبدة والسجق رجّعتنا لأيام زمان.",
    reply: "نورتنا وشرفتنا يا فندم",
  },
  {
    name: "محمد عدلي",
    meta: "مرشد محلي · قبل ٥ أشهر",
    quote:
      "الأكل فوق الممتاز والطعم أصلي أصلي. الكبدة إسكندراني والسجق. اعتمد هذا المكان، والتعامل جميل.",
    reply: "نورتنا وشرفتنا يا فندم",
  },
] as const;
